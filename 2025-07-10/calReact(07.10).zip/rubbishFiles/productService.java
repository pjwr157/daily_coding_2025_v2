package com.cal.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.*;

import com.cal.dto.ListDto;
import com.cal.dto.ProductDto;
import com.cal.service.ProductService;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/product")
public class ProductController {

    private final ProductService service;

    @PostMapping
    public void insertProduct(@RequestBody ProductDto product) {
        service.insertProduct(product);
        log.info("상품 등록: " + product);
    }

    @DeleteMapping("/{id}")
    public void productDelete(@PathVariable int id) {
        service.productDelete(id);
        log.info("삭제된 상품 ID: " + id);
    }

    @GetMapping("/{id}")
    public ProductDto getProduct(@PathVariable int id) {
        return service.getProductById(id);
    }

    @GetMapping
    public Map<String, Object> searchProducts(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String category,
            @RequestParam(defaultValue = "new") String sort,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "8") int size) {

        ListDto criteria = new ListDto();
        criteria.setKeyword(keyword);
        criteria.setCategory(category);
        criteria.setSort(sort);
        criteria.setPage(page);
        criteria.setSize(size);

        List<ProductDto> products = service.getProductsByCriteria(criteria);
        int total = service.getProductCount(criteria);

        Map<String, Object> result = new HashMap<>();
        result.put("products", products);
        result.put("total", total);
        result.put("page", page);
        result.put("size", size);
        return result;
    }
}
