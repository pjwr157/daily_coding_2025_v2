import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:8080/cal/product")
      .then(res => {
        console.log(res.data);
        setProducts(res.data.products);
      })
      .catch(err => {
        console.error("API Error:", err);
      });
  }, []);

  return (
    <div>
      <h1>편의점 상품 목록</h1>
      <ul>
        {products.map(product => (
          <li key={product.id}>
            {product.name} - {product.price}원 - {product.category}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
