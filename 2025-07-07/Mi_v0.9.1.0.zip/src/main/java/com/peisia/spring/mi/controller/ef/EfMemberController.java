package com.peisia.spring.mi.controller.ef;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.peisia.spring.mi.service.ef.member.EfMemberService;
import com.peisia.spring.mi.vo.ef.member.MemberVo;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@SessionAttributes("id")
@Log4j
@RequestMapping("/ef/member")
@AllArgsConstructor
@Controller
public class EfMemberController {
	
	private EfMemberService service;
	
	@GetMapping("/login")
	public void login(){}
	
	
	@PostMapping("/login")
	public String login(MemberVo mvo, Model m){
		MemberVo member = service.login(mvo);
		m.addAttribute("id",member.getId());
		return "redirect:/ef/main";
	}
	
	@GetMapping("/join")
	public void join(){}
	
	@PostMapping("/join")
//	public String join(@RequestParam("id") String id){
//	public String join(String id,String name,String pw){	// 이름이 동일하면 생략 가능
	public String join(MemberVo mvo){	// 이름이 동일하면 생략 가능
		log.info("==== ef ==== : 회원가입처리. id:"+mvo.getId());
		log.info("==== ef ==== : 회원가입처리. 이름:"+mvo.getName());
		log.info("==== ef ==== : 회원가입처리. pw:"+mvo.getPw());
		service.write(mvo);
		return "redirect:/ef/main";
	}

	@GetMapping("/logout")
	public String logout(HttpSession s, SessionStatus status){
		s.removeAttribute("id");
		status.setComplete();  // Model에 있는 SessionAttributes를 제거
		s.invalidate();
		return "redirect:/ef/main";
	}
}