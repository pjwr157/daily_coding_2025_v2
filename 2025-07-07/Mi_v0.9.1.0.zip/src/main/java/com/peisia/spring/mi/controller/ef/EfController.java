package com.peisia.spring.mi.controller.ef;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/ef")
@AllArgsConstructor
@Controller
public class EfController {
	@GetMapping("/main")
	public void main(@SessionAttribute(value = "id", required = false) String id) {
		log.info("==== ef ==== : 세션 id :" + id);
	}
}
