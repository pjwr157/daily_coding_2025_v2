package com.peisia.spring.mi.mapper.ef.member;

import com.peisia.spring.mi.vo.ef.member.MemberVo;

public interface EfMemberMapper {
	public void write(MemberVo mvo);
	public MemberVo login(MemberVo mvo);
}

