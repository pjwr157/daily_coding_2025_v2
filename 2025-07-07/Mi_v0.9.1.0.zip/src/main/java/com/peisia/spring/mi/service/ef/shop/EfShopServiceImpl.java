package com.peisia.spring.mi.service.ef.shop;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.spring.mi.mapper.ef.shop.EfShopMapper;
import com.peisia.spring.mi.vo.ef.shop.ItemVo;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class EfShopServiceImpl implements EfShopService{

	@Setter(onMethod_ = @Autowired)
	private EfShopMapper mapper;

	@Override
	public List<ItemVo> list() {
		return mapper.list();
	}
	
	
}