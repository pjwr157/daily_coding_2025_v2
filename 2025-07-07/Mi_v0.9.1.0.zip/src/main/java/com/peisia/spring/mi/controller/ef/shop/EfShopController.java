package com.peisia.spring.mi.controller.ef.shop;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import com.peisia.spring.mi.service.ef.shop.EfShopService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/ef/shop")
//@AllArgsConstructor
@Controller
public class EfShopController {
	
	@Setter(onMethod_ = @Autowired)
	private EfShopService service;
	
	@GetMapping("/list")
	public void list(@SessionAttribute(value = "id", required = false) String id, Model m) {
		log.info("==== ef ==== : 세션 id :" + id);
		m.addAttribute("list",service.list());
	}
}
