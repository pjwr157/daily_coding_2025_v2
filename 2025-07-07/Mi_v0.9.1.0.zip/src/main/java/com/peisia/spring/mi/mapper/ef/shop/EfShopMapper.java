package com.peisia.spring.mi.mapper.ef.shop;

import java.util.List;

import com.peisia.spring.mi.vo.ef.shop.ItemVo;

public interface EfShopMapper {
	public List<ItemVo> list();
}

