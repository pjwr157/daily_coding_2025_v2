package com.peisia.spring.mi.service.ef.shop;


import java.util.List;

import com.peisia.spring.mi.vo.ef.shop.ItemVo;

public interface EfShopService {
	public List<ItemVo> list();
}
