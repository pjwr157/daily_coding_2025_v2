package com.cal.mapper;

import java.util.List;

import com.cal.dto.ProductDto;

public interface ProductMapper {
    List<ProductDto> productList();
    ProductDto productDetail(int id);
    void productInsert(ProductDto productDto);
    void productUpdate(ProductDto productDto);
    void productDelete(int id);
}
