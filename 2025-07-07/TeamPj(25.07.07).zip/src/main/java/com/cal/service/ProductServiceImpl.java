package com.cal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cal.dto.ProductDto;
import com.cal.mapper.ProductMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class ProductServiceImpl implements ProductService {

	@Setter(onMethod_ = @Autowired)
	private ProductMapper productMapper;

	@Override
	public List<ProductDto> productList() {
		return productMapper.productList();
	}

	@Override
	public ProductDto productDetail(int id) {
		return productMapper.productDetail(id);
	}

	@Override
	public void productInsert(ProductDto productDto) {
		productMapper.productInsert(productDto);
	}

	@Override
	public void productUpdate(ProductDto productDto) {
		productMapper.productUpdate(productDto);
	}

	@Override
	public void productDelete(int id) {
		productMapper.productDelete(id);
	}
}
