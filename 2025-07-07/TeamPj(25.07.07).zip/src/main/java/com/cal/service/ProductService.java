package com.cal.service;

import java.util.List;

import com.cal.dto.ProductDto;

public interface ProductService {
	List<ProductDto> productList();

	ProductDto productDetail(int id);

	void productInsert(ProductDto productDto);

	void productUpdate(ProductDto productDto);

	void productDelete(int id);
}
