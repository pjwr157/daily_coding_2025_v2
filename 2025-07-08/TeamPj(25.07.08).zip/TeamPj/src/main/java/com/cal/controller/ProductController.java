package com.cal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cal.dto.ProductDto;
import com.cal.service.ProductService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RestController
@AllArgsConstructor
@RequestMapping("/api/products")
public class ProductController {

	@Autowired
	private ProductService productService;

	@GetMapping
	@ResponseBody
	public List<ProductDto> productList() {
		return productService.productList();
	}

	@GetMapping("/{id}")
	@ResponseBody
	public ProductDto productDetail(@PathVariable int id) {
		return productService.productDetail(id);
	}

	@PostMapping
	@ResponseBody
	public String productInsert(@RequestBody ProductDto productDto) {
		productService.productInsert(productDto);
		return "insert success";
	}

	@PutMapping("/{id}")
	@ResponseBody
	public String productUpdate(@PathVariable int id, @RequestBody ProductDto productDto) {
		productDto.setId(id);
		productService.productUpdate(productDto);
		return "update success";
	}

	@DeleteMapping("/{id}")
	@ResponseBody
	public String productDelete(@PathVariable int id) {
		productService.productDelete(id);
		return "delete success";
	}
}
