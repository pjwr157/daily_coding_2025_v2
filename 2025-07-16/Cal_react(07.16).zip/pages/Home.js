export default function Home() {
  return (
    <div className="page-container">
      <h1>홈 - 이 사이트는 MUI 컴포넌트 카탈로그입니다.</h1>
      <p>My~로 시작하는 다양한 UI 컴포넌트를 페이지에서 확인할 수 있습니다.</p>
    </div>
  );
}